class m {
    public static void main (String[] args){
        Angle angle = new Angle(20); 
        System.out.println(angle);
        angle.oppose(angle.degre);
        angle.degre(Math.PI);
    }
}