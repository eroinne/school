
class testPixel {
    public static void main(String[] args){
        Pixel P = new Pixel(5,5);
        System.out.println(P);
        P.distance2();
        P.plusloinQue();
    }    
}
